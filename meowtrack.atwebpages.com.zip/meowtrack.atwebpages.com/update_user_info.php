<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

$jsonData = file_get_contents("php://input");
$data = json_decode($jsonData, true);

if ($data !== null && isset($data["user_id"])) {
    $con = mysqli_connect("fdb1028.awardspace.net", "4634431_meowtrack", "A6HN.beL7j9xopn}", "4634431_meowtrack");

    if (!$con) {
        echo json_encode(["success" => false, "message" => "Connection failed"]);
        exit();
    }

    $userId = $data["user_id"];
    $catName = mysqli_real_escape_string($con, $data["cat_name"] ?? '');
    $catAge = mysqli_real_escape_string($con, $data["cat_age"] ?? '');
    $catBreed = mysqli_real_escape_string($con, $data["cat_breed"] ?? '');
    $catColor = mysqli_real_escape_string($con, $data["cat_color"] ?? '');
    $catWeight = floatval($data["cat_weight"] ?? 0);

    $stmt = $con->prepare("UPDATE users SET 
                          cat_name = ?,
                          cat_age = ?,
                          cat_breed = ?,
                          cat_color = ?,
                          cat_weight = ?
                          WHERE id = ?");
    $stmt->bind_param("ssssdi", $catName, $catAge, $catBreed, $catColor, $catWeight, $userId);

    if ($stmt->execute()) {
        echo json_encode(["success" => true]);
    } else {
        echo json_encode(["success" => false, "message" => "Update failed"]);
    }

    $stmt->close();
    mysqli_close($con);
} else {
    echo json_encode(["success" => false, "message" => "Invalid data"]);
}
?>