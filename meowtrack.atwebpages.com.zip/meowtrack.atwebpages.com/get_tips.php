<?php
header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json");

$breed = isset($_GET['breed']) ? trim($_GET['breed']) : '';

$con = mysqli_connect("fdb1028.awardspace.net", "4634431_meowtrack", "A6HN.beL7j9xopn}", "4634431_meowtrack");

if (!$con) {
    echo json_encode(["success" => false, "message" => "Connection failed"]);
    exit();
}

// First get breed-specific tips (case-insensitive comparison)
$stmt = $con->prepare("SELECT tip FROM health_tips WHERE LOWER(breed) = LOWER(?)");
$cleanBreed = strtolower($breed);
$stmt->bind_param("s", $cleanBreed);
$stmt->execute();
$result = $stmt->get_result();

$tips = [];
while ($row = $result->fetch_assoc()) {
    $tips[] = $row['tip'];
}

// If no breed-specific tips found, get general tips
if (empty($tips)) {
    $stmtGeneral = $con->prepare("SELECT tip FROM health_tips WHERE breed IS NULL OR breed = ''");
    $stmtGeneral->execute();
    $resultGeneral = $stmtGeneral->get_result();
    
    while ($row = $resultGeneral->fetch_assoc()) {
        $tips[] = $row['tip'];
    }
}

echo json_encode([
    "success" => true,
    "tips" => $tips,
    "breed" => $breed,
    "isBreedSpecific" => !empty($tips) && $cleanBreed !== ''
]);

$stmt->close();
mysqli_close($con);
?>