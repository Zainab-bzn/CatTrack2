<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$jsonData = file_get_contents("php://input");
$data = json_decode($jsonData, true);

if ($data !== null && isset($data["username"]) && isset($data["email"]) && isset($data["password"])) {
    $con = mysqli_connect("fdb1028.awardspace.net", "4634431_meowtrack", "A6HN.beL7j9xopn}", "4634431_meowtrack");

    if (!$con) {
        echo json_encode(["success" => false, "message" => "Connection failed"]);
        exit();
    }

    $username = $data["username"];
    $email = $data["email"];
    $password = $data["password"];

    // Check if email exists
    $check = $con->prepare("SELECT id FROM users WHERE email = ?");
    $check->bind_param("s", $email);
    $check->execute();
    $check->store_result();

    if ($check->num_rows > 0) {
        echo json_encode(["success" => false, "message" => "Email already exists"]);
        exit();
    }

    // Insert new user
    $stmt = $con->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $username, $email, $password);
    
    if ($stmt->execute()) {
        $userId = $stmt->insert_id;
        echo json_encode([
            "success" => true,
            "user_id" => $userId,
            "username" => $username,
            "email" => $email
        ]);
    } else {
        echo json_encode(["success" => false, "message" => "Registration failed"]);
    }

    $stmt->close();
    mysqli_close($con);
} else {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
}
?>