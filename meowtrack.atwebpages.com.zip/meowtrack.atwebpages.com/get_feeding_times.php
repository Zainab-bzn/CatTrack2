<?php
$host = "fdb1028.awardspace.net";
$user = "4634431_meowtrack";
$password = "A6HN.beL7j9xopn}";
$db = "4634431_meowtrack";

$conn = new mysqli($host, $user, $password, $db);
if ($conn->connect_error) {
    die(json_encode(["status" => "Error", "error" => $conn->connect_error]));
}

$user_id = $_GET['user_id'];

$sql = "SELECT feeding_time1, feeding_time2, feeding_time3, feeding_time4 FROM feeding_times WHERE user_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo json_encode([
        "status" => "Success",
        "feeding_time1" => $row['feeding_time1'],
        "feeding_time2" => $row['feeding_time2'],
        "feeding_time3" => $row['feeding_time3'],
        "feeding_time4" => $row['feeding_time4']
    ]);
} else {
    echo json_encode([
        "status" => "Success",  // No error, just empty
        "feeding_time1" => null,
        "feeding_time2" => null,
        "feeding_time3" => null,
        "feeding_time4" => null
    ]);
}

$conn->close();
?>
