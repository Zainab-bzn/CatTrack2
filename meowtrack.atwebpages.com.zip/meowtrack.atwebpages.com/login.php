<?php
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json");

$jsonData = file_get_contents("php://input");
$data = json_decode($jsonData, true);

if ($data !== null && isset($data["email"]) && isset($data["password"])) {
    $con = mysqli_connect("fdb1028.awardspace.net", "4634431_meowtrack", "A6HN.beL7j9xopn}", "4634431_meowtrack");

    if (!$con) {
        echo json_encode(["success" => false, "message" => "Connection failed"]);
        exit();
    }

    $email = $data["email"];
    $password = $data["password"];

    $stmt = $con->prepare("SELECT id, username, email, password, cat_name, cat_age, cat_breed, cat_color, cat_weight FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        
        if ($password === $row['password']) {
            echo json_encode([
                "success" => true,
                "id" => $row["id"],
                "username" => $row["username"],
                "email" => $row["email"],
                "cat_name" => $row["cat_name"],
                "cat_age" => $row["cat_age"],
                "cat_breed" => $row["cat_breed"],
                "cat_color" => $row["cat_color"],
                "cat_weight" => $row["cat_weight"]
            ]);
        } else {
            echo json_encode(["success" => false, "message" => "Invalid credentials"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "User not found"]);
    }

    $stmt->close();
    mysqli_close($con);
} else {
    echo json_encode(["success" => false, "message" => "Invalid input"]);
}
?>